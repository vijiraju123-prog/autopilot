alert — autopy module for displaying alerts
===========================================

.. automodule:: autopy.alert

Functions
-----------------------------
.. automodule:: autopy.alert

   .. autofunction:: alert(msg: str, title: str=None, default_button: str=None, cancel_button: str=None)
