color — autopy module for working with colors
=============================================

.. automodule:: autopy.color

Functions
-----------------------------
.. automodule:: autopy.color

  .. autofunction:: rgb_to_hex(red: int, green: int, blue: int) -> int
  .. autofunction:: hex_to_rgb(hex: int) -> Tuple[int, int, int]
