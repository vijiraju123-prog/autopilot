autopy — API Reference
==================================

.. automodule:: autopy


Table Of Contents
------------------
.. toctree::
   :titlesonly:
   :maxdepth: 20
   :glob:

   alert <alert>
   bitmap <bitmap>
   color <color>
   key <key>
   mouse <mouse>
   screen <screen>
