import autopy

autopy.alert.alert("Hello, world!")
