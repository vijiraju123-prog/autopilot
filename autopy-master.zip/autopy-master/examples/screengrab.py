import autopy

autopy.bitmap.capture_screen().save("screenshot.png")
